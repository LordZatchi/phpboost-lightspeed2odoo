<?php
/**
 * @copyright   &copy; 2005-2024 PHPBoost
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      Regis VIARRE <crowkait@phpboost.com>
 * @version     PHPBoost 6.0 - last update: 2015 09 30
 * @since       PHPBoost 1.2 - 2005 10 25
 * @contributor Benoit SAUTEL <ben.popeye@phpboost.com>
 * @contributor Julien BRISWALTER <j1.seth@phpboost.com>
*/

define('PATH_TO_ROOT', '..');

require_once PATH_TO_ROOT . '/kernel/init.php';

$url_controller_mappers = array(
	// Configuration
	new UrlControllerMapper('AdminDatabaseConfigController', '`^/admin(?:/config)?/?$`'),

	new UrlControllerMapper('DatabaseHomeController', '`^/?$`'),
);
DispatchManager::dispatch($url_controller_mappers);
?>
