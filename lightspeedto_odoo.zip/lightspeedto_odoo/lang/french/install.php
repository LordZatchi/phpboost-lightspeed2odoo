<?php
/**
 * @copyright   &copy; 2024 LordZatchi
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      LordZatchi <zatchbell68@gmail.com>
 * @version     PHPBoost 6.0 - last update: 2024 01 01
 * @since       PHPBoost 6.0 - 2024 01 01
 */

####################################################
#                       French                     #
####################################################

$lang['default.mapping.name'] = 'Mapping Lightspeed par défaut';
$lang['default.mapping.description'] = 'Mapping par défaut pour les exports Lightspeed Série K';
?>
