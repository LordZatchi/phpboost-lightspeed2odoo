<?php

/**
 * @copyright   &copy; 2025 LordZatchi
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL-3.0
 * @author      LordZatchi <zatchbell68@gmail.com>
 * @version     PHPBoost 6.0 - last update: 2025 01 16
 * @since       PHPBoost 6.0 - 2025 01 16
 */

####################################################
#                    PARTIE 1/3                   #
#         TITRES ET NAVIGATION DU MODULE          #
####################################################

// Titre principal du module
$lang['lightspeedto_odoo.module.title'] = 'Lightspeed vers Odoo';

// Navigation et liens principaux
$lang['lightspeedto_odoo.home'] = 'Accueil';
$lang['lightspeedto_odoo.upload'] = 'Uploader un fichier';
$lang['lightspeedto_odoo.mappings'] = 'Gestion des mappings';
$lang['lightspeedto_odoo.process'] = 'Traitement des données';
$lang['lightspeedto_odoo.admin.config'] = 'Configuration du module';

// Sous-menus et actions
$lang['lightspeedto_odoo.mappings.add'] = 'Ajouter un mapping';
$lang['lightspeedto_odoo.mappings.edit'] = 'Modifier le mapping';
$lang['lightspeedto_odoo.mappings.delete'] = 'Supprimer le mapping';
$lang['lightspeedto_odoo.mappings.management'] = 'Gestion des mappings';

// Pages d'accueil
$lang['lightspeedto_odoo.home.welcome'] = 'Bienvenue dans le module Lightspeed vers Odoo';
$lang['lightspeedto_odoo.home.description'] = 'Ce module permet de transférer facilement vos données CSV de Lightspeed Série K vers Odoo POS avec un système de mapping configurable.';
$lang['lightspeedto_odoo.home.quick.actions'] = 'Actions rapides';
$lang['lightspeedto_odoo.home.recent.uploads'] = 'Derniers uploads';
$lang['lightspeedto_odoo.home.statistics'] = 'Statistiques';

// Titres des sections
$lang['lightspeedto_odoo.section.upload'] = 'Upload de fichier';
$lang['lightspeedto_odoo.section.mappings'] = 'Mappings';
$lang['lightspeedto_odoo.section.process'] = 'Traitement';
$lang['lightspeedto_odoo.section.config'] = 'Configuration';

// Breadcrumb et navigation
$lang['lightspeedto_odoo.breadcrumb.home'] = 'Accueil';
$lang['lightspeedto_odoo.breadcrumb.upload'] = 'Upload';
$lang['lightspeedto_odoo.breadcrumb.mappings'] = 'Mappings';
$lang['lightspeedto_odoo.breadcrumb.process'] = 'Traitement';
$lang['lightspeedto_odoo.breadcrumb.admin'] = 'Administration';

// Documentation
$lang['lightspeedto_odoo.documentation'] = 'Documentation';
$lang['lightspeedto_odoo.help'] = 'Aide';
$lang['lightspeedto_odoo.about'] = 'À propos';

// === FORMULAIRES GÉNÉRAUX ===
$lang['lightspeedto_odoo.form.name'] = 'Nom';
$lang['lightspeedto_odoo.form.description'] = 'Description';
$lang['lightspeedto_odoo.form.file'] = 'Fichier';
$lang['lightspeedto_odoo.form.mapping'] = 'Mapping';
$lang['lightspeedto_odoo.form.save'] = 'Sauvegarder';
$lang['lightspeedto_odoo.form.cancel'] = 'Annuler';
$lang['lightspeedto_odoo.form.delete'] = 'Supprimer';
$lang['lightspeedto_odoo.form.edit'] = 'Modifier';
$lang['lightspeedto_odoo.form.view'] = 'Voir';
$lang['lightspeedto_odoo.form.download'] = 'Télécharger';
$lang['lightspeedto_odoo.form.process'] = 'Traiter';
$lang['lightspeedto_odoo.form.required'] = 'Requis';
$lang['lightspeedto_odoo.form.optional'] = 'Optionnel';

// === UPLOAD DE FICHIERS ===
$lang['lightspeedto_odoo.upload.title'] = 'Upload de fichier CSV';
$lang['lightspeedto_odoo.upload.choose.file'] = 'Choisir un fichier CSV';
$lang['lightspeedto_odoo.upload.choose.mapping'] = 'Choisir un mapping';
$lang['lightspeedto_odoo.upload.file.info'] = 'Informations sur le fichier';
$lang['lightspeedto_odoo.upload.file.size'] = 'Taille du fichier';
$lang['lightspeedto_odoo.upload.file.type'] = 'Type de fichier';
$lang['lightspeedto_odoo.upload.file.rows'] = 'Nombre de lignes';
$lang['lightspeedto_odoo.upload.submit'] = 'Uploader le fichier';
$lang['lightspeedto_odoo.upload.drag.drop'] = 'Glissez-déposez votre fichier CSV ici ou cliquez pour sélectionner';
$lang['lightspeedto_odoo.upload.max.size'] = 'Taille maximale autorisée : {MAX_SIZE}';
$lang['lightspeedto_odoo.upload.allowed.formats'] = 'Formats autorisés : CSV';

// === MAPPINGS ===
$lang['lightspeedto_odoo.mapping.title'] = 'Gestion des mappings';
$lang['lightspeedto_odoo.mapping.name'] = 'Nom du mapping';
$lang['lightspeedto_odoo.mapping.description'] = 'Description du mapping';
$lang['lightspeedto_odoo.mapping.data'] = 'Données de mapping';
$lang['lightspeedto_odoo.mapping.is.default'] = 'Mapping par défaut';
$lang['lightspeedto_odoo.mapping.created'] = 'Créé le';
$lang['lightspeedto_odoo.mapping.updated'] = 'Modifié le';
$lang['lightspeedto_odoo.mapping.author'] = 'Auteur';
$lang['lightspeedto_odoo.mapping.add'] = 'Ajouter un mapping';
$lang['lightspeedto_odoo.mapping.edit'] = 'Modifier le mapping';
$lang['lightspeedto_odoo.mapping.delete'] = 'Supprimer le mapping';
$lang['lightspeedto_odoo.mapping.copy'] = 'Copier le mapping';
$lang['lightspeedto_odoo.mapping.set.default'] = 'Définir comme défaut';
$lang['lightspeedto_odoo.mapping.remove.default'] = 'Retirer le défaut';

// === MAPPING FIELDS ===
$lang['lightspeedto_odoo.mapping.lightspeed.field'] = 'Champ Lightspeed';
$lang['lightspeedto_odoo.mapping.odoo.field'] = 'Champ Odoo';
$lang['lightspeedto_odoo.mapping.transformation'] = 'Transformation';
$lang['lightspeedto_odoo.mapping.required'] = 'Requis';
$lang['lightspeedto_odoo.mapping.add.field'] = 'Ajouter un champ';
$lang['lightspeedto_odoo.mapping.remove.field'] = 'Supprimer le champ';

// === TRAITEMENT ===
$lang['lightspeedto_odoo.process.title'] = 'Traitement des données';
$lang['lightspeedto_odoo.process.start'] = 'Démarrer le traitement';
$lang['lightspeedto_odoo.process.stop'] = 'Arrêter le traitement';
$lang['lightspeedto_odoo.process.pause'] = 'Mettre en pause';
$lang['lightspeedto_odoo.process.resume'] = 'Reprendre';
$lang['lightspeedto_odoo.process.retry'] = 'Réessayer';
$lang['lightspeedto_odoo.process.details'] = 'Détails du traitement';
$lang['lightspeedto_odoo.process.preview'] = 'Aperçu des données';
$lang['lightspeedto_odoo.process.validate'] = 'Valider les données';
$lang['lightspeedto_odoo.process.export'] = 'Exporter vers Odoo';

// === ACTIONS ===
$lang['lightspeedto_odoo.action.confirm.delete'] = 'Êtes-vous sûr de vouloir supprimer cet élément ?';
$lang['lightspeedto_odoo.action.confirm.process'] = 'Êtes-vous sûr de vouloir traiter ce fichier ?';
$lang['lightspeedto_odoo.action.confirm.export'] = 'Êtes-vous sûr de vouloir exporter ces données vers Odoo ?';

// === STATUTS ===
$lang['lightspeedto_odoo.status.pending'] = 'En attente';
$lang['lightspeedto_odoo.status.processing'] = 'En cours de traitement';
$lang['lightspeedto_odoo.status.completed'] = 'Terminé';
$lang['lightspeedto_odoo.status.failed'] = 'Échec';
$lang['lightspeedto_odoo.status.cancelled'] = 'Annulé';
$lang['lightspeedto_odoo.status.paused'] = 'En pause';
$lang['lightspeedto_odoo.status.validated'] = 'Validé';
$lang['lightspeedto_odoo.status.exported'] = 'Exporté';

// === MESSAGES DE SUCCÈS ===
$lang['lightspeedto_odoo.success.file.uploaded'] = 'Le fichier a été uploadé avec succès';
$lang['lightspeedto_odoo.success.mapping.saved'] = 'Le mapping a été sauvegardé avec succès';
$lang['lightspeedto_odoo.success.mapping.deleted'] = 'Le mapping a été supprimé avec succès';
$lang['lightspeedto_odoo.success.processing.started'] = 'Le traitement a démarré avec succès';
$lang['lightspeedto_odoo.success.processing.completed'] = 'Le traitement s\'est terminé avec succès';
$lang['lightspeedto_odoo.success.data.exported'] = 'Les données ont été exportées vers Odoo avec succès';
$lang['lightspeedto_odoo.success.config.saved'] = 'La configuration a été sauvegardée avec succès';

// === MESSAGES D'ERREUR ===
$lang['lightspeedto_odoo.error.file.not.found'] = 'Fichier non trouvé';
$lang['lightspeedto_odoo.error.file.invalid.format'] = 'Format de fichier invalide. Seuls les fichiers CSV sont acceptés';
$lang['lightspeedto_odoo.error.file.too.large'] = 'Le fichier est trop volumineux';
$lang['lightspeedto_odoo.error.file.upload.failed'] = 'L\'upload du fichier a échoué';
$lang['lightspeedto_odoo.error.mapping.not.found'] = 'Mapping non trouvé';
$lang['lightspeedto_odoo.error.mapping.invalid'] = 'Mapping invalide';
$lang['lightspeedto_odoo.error.processing.failed'] = 'Le traitement a échoué';
$lang['lightspeedto_odoo.error.export.failed'] = 'L\'export vers Odoo a échoué';
$lang['lightspeedto_odoo.error.connection.odoo'] = 'Erreur de connexion à Odoo';
$lang['lightspeedto_odoo.error.permission.denied'] = 'Permissions insuffisantes';
$lang['lightspeedto_odoo.error.database'] = 'Erreur de base de données';
$lang['lightspeedto_odoo.error.csv.parsing'] = 'Erreur lors de l\'analyse du fichier CSV';
$lang['lightspeedto_odoo.error.data.validation'] = 'Erreur de validation des données';

// === STATISTIQUES ET INFORMATIONS ===
$lang['lightspeedto_odoo.stats.total.uploads'] = 'Total des uploads';
$lang['lightspeedto_odoo.stats.processed.files'] = 'Fichiers traités';
$lang['lightspeedto_odoo.stats.failed.files'] = 'Fichiers en échec';
$lang['lightspeedto_odoo.stats.total.rows'] = 'Total des lignes';
$lang['lightspeedto_odoo.stats.processed.rows'] = 'Lignes traitées';
$lang['lightspeedto_odoo.stats.error.rows'] = 'Lignes en erreur';
$lang['lightspeedto_odoo.stats.success.rate'] = 'Taux de succès';
$lang['lightspeedto_odoo.stats.processing.time'] = 'Temps de traitement';
$lang['lightspeedto_odoo.stats.average.time'] = 'Temps moyen';

// === CONFIGURATION ===
$lang['lightspeedto_odoo.config.title'] = 'Configuration du module Lightspeed vers Odoo';
$lang['lightspeedto_odoo.config.odoo.settings'] = 'Paramètres Odoo';
$lang['lightspeedto_odoo.config.odoo.url'] = 'URL Odoo';
$lang['lightspeedto_odoo.config.odoo.database'] = 'Base de données Odoo';
$lang['lightspeedto_odoo.config.odoo.username'] = 'Nom d\'utilisateur Odoo';
$lang['lightspeedto_odoo.config.odoo.password'] = 'Mot de passe Odoo';
$lang['lightspeedto_odoo.config.upload.settings'] = 'Paramètres d\'upload';
$lang['lightspeedto_odoo.config.max.file.size'] = 'Taille maximale de fichier (MB)';
$lang['lightspeedto_odoo.config.upload.path'] = 'Chemin d\'upload';
$lang['lightspeedto_odoo.config.processing.settings'] = 'Paramètres de traitement';
$lang['lightspeedto_odoo.config.batch.size'] = 'Taille des lots de traitement';
$lang['lightspeedto_odoo.config.timeout'] = 'Timeout (secondes)';
$lang['lightspeedto_odoo.config.auto.process'] = 'Traitement automatique';
$lang['lightspeedto_odoo.config.test.connection'] = 'Tester la connexion';
$lang['lightspeedto_odoo.config.connection.success'] = 'Connexion réussie';
$lang['lightspeedto_odoo.config.connection.failed'] = 'Connexion échouée';

// === TABLEAUX ET LISTES ===
$lang['lightspeedto_odoo.table.filename'] = 'Nom du fichier';
$lang['lightspeedto_odoo.table.upload.date'] = 'Date d\'upload';
$lang['lightspeedto_odoo.table.status'] = 'Statut';
$lang['lightspeedto_odoo.table.rows'] = 'Lignes';
$lang['lightspeedto_odoo.table.errors'] = 'Erreurs';
$lang['lightspeedto_odoo.table.actions'] = 'Actions';
$lang['lightspeedto_odoo.table.author'] = 'Auteur';
$lang['lightspeedto_odoo.table.created'] = 'Créé';
$lang['lightspeedto_odoo.table.updated'] = 'Modifié';
$lang['lightspeedto_odoo.table.size'] = 'Taille';
$lang['lightspeedto_odoo.table.progress'] = 'Progression';

// === MESSAGES DIVERS ===
$lang['lightspeedto_odoo.no.data'] = 'Aucune donnée disponible';
$lang['lightspeedto_odoo.no.files'] = 'Aucun fichier uploadé';
$lang['lightspeedto_odoo.no.mappings'] = 'Aucun mapping configuré';
$lang['lightspeedto_odoo.loading'] = 'Chargement en cours...';
$lang['lightspeedto_odoo.processing'] = 'Traitement en cours...';
$lang['lightspeedto_odoo.please.wait'] = 'Veuillez patienter...';
$lang['lightspeedto_odoo.operation.cancelled'] = 'Opération annulée';
$lang['lightspeedto_odoo.operation.completed'] = 'Opération terminée';

// === TOOLTIPS ET AIDE ===
$lang['lightspeedto_odoo.help.csv.format'] = 'Le fichier CSV doit contenir les colonnes d\'export de Lightspeed Série K';
$lang['lightspeedto_odoo.help.mapping.config'] = 'Configurez ici la correspondance entre les champs Lightspeed et Odoo';
$lang['lightspeedto_odoo.help.processing'] = 'Le traitement peut prendre quelques minutes selon la taille du fichier';
$lang['lightspeedto_odoo.help.odoo.connection'] = 'Vérifiez que votre instance Odoo est accessible et que les identifiants sont corrects';
